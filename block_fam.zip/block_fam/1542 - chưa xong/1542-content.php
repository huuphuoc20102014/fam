<?php
$url_host = 'http://' . $_SERVER['HTTP_HOST'];
$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');
$pattern_uri = '/' . $pattern_document_root . '(.*)$/';
preg_match_all($pattern_uri, __DIR__, $matches);
$url_path = $url_host . $matches[1][0];
$url_path = str_replace('\\', '/', $url_path);
?>

<div class="type-1542">
	<div class="row">
		<div class="col-md-9">
			<section id="content-1542">
				<div class="row">
					<div class="col-md-6">
						<div class="cmsms-1542-left-column">
							<span class="onsale">
								Sale!
							</span>
						</div>
					</div>
					<div class="col-md-6">
						
					</div>
				</div>
			</section>
		</div>

		<div class="col-md-3">
			
		</div>
	</div>
</div>
