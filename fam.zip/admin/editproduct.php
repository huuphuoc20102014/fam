<?php
	//require "../app/config.php";
	require "../app/db.php";
	$db = new db();
	$id = $_GET['id'];
	if (isset($_POST['edit']))
	{
		if (isset($_FILES['fileUpload']))
		{
			$image = $_FILES['fileUpload']['name'];
			$file_tmp = $_FILES['fileUpload']['tmp_name'];
		}
		else
		{
			$image = "";
		}
		$name = $_POST['name'];
		$type_id = $_POST['type_id'];
		$manu_id = $_POST['manu_id'];
		$description = $_POST['description'];
		$price = $_POST['price'];
		$feature = $_POST['feature'];
		$edit = $db->editProduct($name, $manu_id, $price, $image, $description, $feature, $id);

		if (isset($edit))
		{
			move_uploaded_file($file_tmp,"public/images/".$image);
			header('location:index.php');
		}
	}
?>