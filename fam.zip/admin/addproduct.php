<?php
	//require "../app/config.php";
	require "../db.php";
	$db = new db();
	if (isset($_POST['add']))
	{
		$product_name = $_POST['product_name'];
		$category_id = $_POST['category_id'];
		$fam_category_id = $_POST['category_id'];
		$mota = $_POST['mota'];
		$product_price = $_POST['product_price'];
		if (isset($_FILES['fileUpload']))
		{
			$file_name = $_FILES['fileUpload']['name'];
			$product_images = $_FILES['fileUpload']['name'];
			$file_tmp = $_FILES['fileUpload']['tmp_name'];
		}
		echo $product_name;
		echo $fam_category_id;
		echo $product_price;
		echo $product_images;
		$add = $db->addProduct($product_name, $fam_category_id, $product_price, $product_images, $mota);
		var_dump($add);
		if (isset($add))
		{
			move_uploaded_file($file_tmp,"public/images/".$file_name);
			header('location:admin_home.php');
		}
	}
?>