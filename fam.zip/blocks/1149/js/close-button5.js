$(document).ready(function(){
    $("#close-link5").click(function(){
      
        $(".x_panel5").toggle();

    });
    
});
